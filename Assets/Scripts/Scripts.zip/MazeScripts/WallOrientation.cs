namespace MazeScripts
{
    public enum WallOrientation
    {
        WEST = 0,
        NORTH = 1,
        EAST = 2,
        SOUTH = 3
    }
}